#1. Load packages
library(rnaturalearth) #to visualize
library(terra) #to manage spatial data
library(sf) #to manage spatial data
library(ggplot2) #to make nice graphs
library(tidyterra) #to make nice graphs of spatial data
library(tsbox) #to work with time series
library(dplyr) #to deal with dataframe manipulation
library(tidyr) #to deal with dataframe manipulation
library(lubridate) #to deal with dates

#2. Define your working directory
setwd('C:/Users/jvpassel/OneDrive - UGent/Postdoc/Research stay/Lab/Ideas_workshop/workshop_materials')

#3. Load data from GEE
tmax_annual<-rast('./example_france/example_france_day1_terraClimate1995_2024_tmax_annual.tif')
tmax_monthly_loc<-read.csv('./example_france/example_france_day1_terraClimate1995_2024_locations.csv')
locations<-vect('./example_france/example_france_day1_locations.shp')
locations_sf<-st_as_sf(locations) 

#4. Visualize spatial data
#create background of country contours
world <- rnaturalearth::ne_countries(scale = "medium", returnclass = "sf") 
france<-rnaturalearth::ne_countries(country = 'france', returnclass = "sf")
#france has many overseas territories, only keep the mainland France
#extract individual polygons
france_parts <- st_cast(france, "POLYGON")
#calculate area and keep the largest polygon
france_europe <- france_parts[which.max(st_area(france_parts)), ]
plot(france_europe[1])

#Crop annual temp to France borders
tmax_annual_france<-mask(tmax_annual,france_europe)
plot(tmax_annual_france[[1]])
plot(locations_sf,add=T,col='black')

#calculate mean annual temperature
tmax_annual_mean<-mean(tmax_annual_france)
plot(tmax_annual_mean)
ggplot() +
  geom_spatraster(data=tmax_annual_mean) +
  scale_fill_gradient('Mean annual\nmax temperature\n1995-2024 (°C)',
                      low='darkblue',high='darkorange',na.value=NA,limits=c(0,22)) +
  geom_sf(data = france_europe,fill = NA, color = "grey17") +
  geom_sf(data = locations_sf,color='black',size=1)+
  scale_y_continuous("Latitude",expand = c(0, 0)) +
  scale_x_continuous("Longitude",expand = c(0, 0)) +
  theme_bw()+
  theme(axis.text = element_text(size=7),legend.position = "right")

# Plot time series of monthly max temperatures over locations
colnames(tmax_monthly_loc)
tmax_monthly_loc_df<-tmax_monthly_loc[,c(2,3,6)] #select useful columns
tmax_monthly_loc_df$date<-as.Date(tmax_monthly_loc_df$date) #convert dates to Date format in R

#plot all lines on top of each other
ggplot(tmax_monthly_loc_df)+
  geom_line(mapping = aes(x = date,y = tmax, color = SiteID)) + #plot every SiteID in different colour
  scale_color_manual(values=c("orange","red",'forestgreen','skyblue','darkblue')) + #manually choose colours per site
  xlab('Date') +
  ylab('Monthly max temperature (°C)') +
  theme_bw()

#plot all lines separately, using facet_wrap(~SiteID)
ggplot(tmax_monthly_loc_df)+
  geom_line(mapping = aes(x = date,y = tmax, color = SiteID)) + #plot every SiteID in different colour
  scale_color_manual(values=c("orange","red",'forestgreen','skyblue','darkblue')) + #manually choose colours per site
  xlab('Date') +
  ylab('Monthly max temperature (°C)') +
  facet_wrap(~ SiteID) +
  theme_bw()

##5. Calculate temperature anomalies
#calculate mean and SD of monthly temperature
tmax_monthly_loc_stats <- tmax_monthly_loc_df %>%
  mutate(month = month(date)) %>%
  group_by(SiteID, month) %>%
  summarise(
    mean_temp = mean(tmax, na.rm = TRUE),
    sd_temp = sd(tmax, na.rm = TRUE),
    .groups = "drop"
  )

#add to original dataframe
tmax_monthly_loc_df_anomaly <- tmax_monthly_loc_df %>%
  mutate(month = month(date)) %>%
  left_join(
    tmax_monthly_loc_stats,
    by = c("SiteID", "month")
  )

#calculate anomalies
tmax_monthly_loc_df_anomaly$tmax_an<-(tmax_monthly_loc_df_anomaly$tmax-tmax_monthly_loc_df_anomaly$mean_temp)/
  tmax_monthly_loc_df_anomaly$sd_temp

#plot
ggplot(tmax_monthly_loc_df_anomaly)+
  geom_line(mapping = aes(x = date,y = tmax_an, color = SiteID)) + #plot every SiteID in different colour
  scale_color_manual(values=c("orange","red",'forestgreen','skyblue','darkblue')) + #manually choose colours per site
  xlab('Date') +
  ylab('Monthly temperature anomaly') +
  facet_wrap(~ SiteID) +
  theme_bw()

#indicate heatwave months, using definition of 1SD or 2SD above normal
tmax_monthly_loc_df_anomaly$heat_1SD<-ifelse(tmax_monthly_loc_df_anomaly$tmax_an>1,tmax_monthly_loc_df_anomaly$tmax_an,NA)
tmax_monthly_loc_df_anomaly$heat_2SD<-ifelse(tmax_monthly_loc_df_anomaly$tmax_an>2,tmax_monthly_loc_df_anomaly$tmax_an,NA)
write.csv(tmax_monthly_loc_df_anomaly,'./example_france/example_france_day1_terraClimate1995_2024_locations_anomalies.csv')

ggplot(tmax_monthly_loc_df_anomaly)+
  geom_line(mapping = aes(x = date,y = tmax_an, color = SiteID)) + #plot every SiteID in different colour
  geom_point(mapping = aes(x = date,y = heat_2SD)) + #plot extreme months with black dots
  scale_color_manual(values=c("orange","red",'forestgreen','skyblue','darkblue')) + #manually choose colours per site
  xlab('Date') +
  ylab('Monthly temperature anomaly') +
  facet_wrap(~ SiteID) +
  theme_bw()

#define heatwave periods as starting with at least two months of large postive anomaly and ending when anomaly gets negative
#from my recent article (Van Passel et al., 2026, Earth's Future)
posanomaly<-1 #change to how big anomaly should be ~ 1 or 2 SD
find_hot_periods<-function(x){
  if(!all(is.na(x))){
    posindex<-which(x>0) # Find positions of all positive anomalies
    signposindex<-which(x>posanomaly) # Find positions of positive anomalies
    if(length(signposindex)!=0){
      hotstart<-split(signposindex, cumsum(c(1, diff(signposindex) != 1))) # Make list of all separate significant events
      hotlist<-list()
      for(i in 1:length(hotstart)){
        if(length(hotstart[[i]])>1){ # event should start with at least two months of pos anomaly
          start<-which(posindex==hotstart[[i]][[1]]) # Find position of event start
          posindex_2<-posindex[-c(1:(start-1))] # Delete everything before this event
          hot<-cumsum(c(1, diff(posindex_2) != 1)) # See how many months were hot after event start
          if(sum(hot==1)>1){ # Should be at least 1 month afterwards (sum at least 2)
            dur<-sum(hot==1)
            hotlist[[i]]<-c(posindex[start]:(posindex[start]+dur-1)) # Get positions of total events
          }
        }
      }
      if(length(hotlist)!=0){
        if(length(which(sapply(hotlist, is.null)))>0){
          hotlist<-hotlist[-which(sapply(hotlist, is.null))] # Remove empty list elements (due to hotstart = 1 or sum = 1)
        }
        if(length(hotlist)!=0){
          hots<-unlist(hotlist)
          y<-x
          y[-hots]<-NA # Only events are not NA
        } 
      } else {
        y<-rep(NA,length(x))
      }
    } else { 
      y<-rep(NA,length(x))
    }
  } else {
    y<-rep(NA,length(x))
  }
  return(y)
}

tmax_monthly_loc_df_anomaly <- tmax_monthly_loc_df_anomaly %>%
  arrange(SiteID, date) %>%
  group_by(SiteID) %>%
  mutate(
    hot_period = find_hot_periods(tmax_an)
  ) %>%
  ungroup()
tmax_monthly_loc_df_anomaly$tmax_hot<-ifelse(!is.na(tmax_monthly_loc_df_anomaly$hot_period),tmax_monthly_loc_df_anomaly$tmax,NA)

ggplot(tmax_monthly_loc_df_anomaly)+
  geom_line(mapping = aes(x = date,y = tmax_an, color = SiteID)) + #plot every SiteID in different colour
  geom_line(mapping = aes(x = date,y = hot_period)) + #plot hot periods with black line
  scale_color_manual(values=c("orange","red",'forestgreen','skyblue','darkblue')) + #manually choose colours per site
  xlab('Date') +
  ylab('Monthly temperature anomaly') +
  facet_wrap(~ SiteID) +
  theme_bw()
ggplot(tmax_monthly_loc_df_anomaly)+
  geom_line(mapping = aes(x = date,y = tmax, color = SiteID)) + #plot every SiteID in different colour
  geom_line(mapping = aes(x = date,y = tmax_hot)) + #plot hot periods with black line
  scale_color_manual(values=c("orange","red",'forestgreen','skyblue','darkblue')) + #manually choose colours per site
  xlab('Date') +
  ylab('Monthly max temperature (°C)') +
  facet_wrap(~ SiteID) +
  theme_bw()
