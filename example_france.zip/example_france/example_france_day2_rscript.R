#1. Load packages
library(rnaturalearth) #to visualize
library(terra) #to manage spatial data
library(sf) #to manage spatial data
library(ggplot2) #to make nice graphs
library(tidyterra) #to make nice graphs of spatial data
library(tsbox) #to work with time series
library(dplyr) #to deal with dataframe manipulation
library(tidyr) #to deal with dataframe manipulation
library(MuMIn)

#2. Define your working directory
setwd('C:/Users/jvpassel/OneDrive - UGent/Postdoc/Research stay/Lab/Ideas_workshop/workshop_materials')

#3. Load data from GEE
ls_mean<-rast('./example_france/example_france_day2_LandsatMean_1995_2024.tif')
ls_ndvi_loc<-read.csv('./example_france/example_france_day2_landsatNDVI_1995_2024_locations.csv')
locations<-vect('./example_france/example_france_day1_locations.shp')
locations_sf<-st_as_sf(locations) 

#4. Visualize spatial data
#create background of country contours
world <- rnaturalearth::ne_countries(scale = "medium", returnclass = "sf") 
france<-rnaturalearth::ne_countries(country = 'france', returnclass = "sf")
#france has many overseas territories, only keep the mainland France
#extract individual polygons
france_parts <- st_cast(france, "POLYGON")
#calculate area and keep the largest polygon
france_europe <- france_parts[which.max(st_area(france_parts)), ]
plot(france_europe[1])

#Crop mean bands to France borders
ls_mean_france<-mask(ls_mean,france_europe)
plot(ls_mean_france)

#Suppose I am interested in the spatial spread of vegetation biomass: use of EVI
ls_mean_france$EVI<-2.5 * ((ls_mean_france$NIR - ls_mean_france$red) / 
                             (ls_mean_france$NIR + 6 * ls_mean_france$red - 7.5 * ls_mean_france$blue + 1))

## Plot mean Landsat EVI
plot(ls_mean_france$EVI)
ls_mean_france$EVI #values below 0 are not vegetation, so can be ignored in graph
ggplot() +
  geom_spatraster(data=ls_mean_france$EVI) +
  scale_fill_gradient('Mean Landsat\nEVI 1995-2024',
                      low='gold',high='forestgreen',na.value=NA,limits=c(0,0.6)) +
  geom_sf(data = france_europe,fill = NA, color = "grey17") +
  geom_sf(data = locations_sf,color='black',size=1) +
  geom_sf_text(data = locations_sf, aes(label = SiteID), nudge_x = 0.4, nudge_y = 0.4) +
  scale_y_continuous("Latitude",expand = c(0, 0)) +
  scale_x_continuous("Longitude",expand = c(0, 0)) +
  theme_bw()+
  theme(axis.text = element_text(size=7),legend.position = "right")

# Plot time series of monthly NDVI over locations
colnames(ls_ndvi_loc)
ls_ndvi_loc_df<-ls_ndvi_loc[,c(2,3,5)] #select useful columns
ls_ndvi_loc_df$date<-as.Date(ls_ndvi_loc_df$date) #convert dates to Date format in R

ggplot(ls_ndvi_loc_df)+
  geom_line(mapping = aes(x = date,y = meanNDVI, color = SiteID)) + #plot every SiteID in different colour
  #geom_point(mapping = aes(x = date,y = meanNDVI, color = SiteID)) + #plot every SiteID in different colour
  scale_color_manual(values=c("orange","red",'forestgreen','skyblue','darkblue')) + #manually choose colours per site
  xlab('Date') +
  ylab('Monthly NDVI') +
  theme_bw()
#the strange signal for E shows clearly that I accidently put the point in a non-vegetated area,
#this is where I would use QGIS to check the exact locations
#In QGIS, it was clear that point E is located in a lake, while point C is located in an industrial zone, oops
#Therefore, I will only do the comparison with temperature for points A, B and D

## Relate NDVI and temperature over plot locations
tmax_monthly_loc_df_anomaly<-read.csv('./example_france/example_france_day1_terraClimate1995_2024_locations_anomalies.csv')[,-1]
tmax_monthly_loc_df_anomaly$date<-as.Date(tmax_monthly_loc_df_anomaly$date) #convert dates to Date format in R

#combine into one dataframe
monthly_ndvi_tmax <- left_join(tmax_monthly_loc_df_anomaly, ls_ndvi_loc_df,
                               by = c("SiteID", "date"))
#only keep rows for A, B, D
monthly_ndvi_tmax<-monthly_ndvi_tmax[monthly_ndvi_tmax$SiteID %in% c('A','B','D'),]
number_missingvalues<-monthly_ndvi_tmax %>%
  group_by(SiteID) %>%
  summarise(
    n_NA = sum(is.na(meanNDVI))
  )
number_missingvalues #A has the highest number of missing NDVI values in the time series

#plot time series per site
ggplot(monthly_ndvi_tmax, aes(date)) +
  geom_line(aes(y = tmax), col = "blue") +
  #If you want to plot two y-axes, you have to multiply the second one 
  #with a value so that the extent of the two axes is similar
  #temperature goes between 0 and 30, while NDVI between 0 and 1,
  #so multiply NDVI by 30 and divide the secondary axis by 30
  geom_point(aes(y = meanNDVI * 30), colour = "darkgreen") +
  geom_line(aes(y = meanNDVI * 30), colour = "darkgreen") +
  facet_wrap(~SiteID, ncol = 2) +
  scale_y_continuous(
    name = "max temperature (°C)",
    sec.axis = sec_axis(~./30, name = "NDVI")
  ) +
  theme_bw()

#plot scatter plot between NDVI and tmax
ggplot(monthly_ndvi_tmax, aes(tmax, meanNDVI)) +
  geom_point() +
  geom_smooth(method = "lm", se = TRUE) +
  theme_bw()
ggplot(monthly_ndvi_tmax, aes(tmax, meanNDVI)) +
  geom_point() +
  geom_smooth(method = "lm", se = TRUE) +
  facet_wrap(~SiteID) +
  theme_bw()

#calculate pearson correlation
corr<-monthly_ndvi_tmax %>%
  group_by(SiteID) %>%
  summarise(
    cor = cor(tmax, meanNDVI, use = "complete.obs"),
    p = cor.test(tmax, meanNDVI)$p.value
  )
corr 
#all significant positive correlations between tmax and NDVI,
#but lowest correlation for site D, which is also the warmest site
monthly_ndvi_tmax %>%
  group_by(SiteID) %>%
  summarise(
    mean_tmax = mean(tmax))

#consider a lag
#NDVI at time t is being related to temperature at time t − 1
monthly_ndvi_tmax <- monthly_ndvi_tmax %>%
  arrange(SiteID, date) %>%
  group_by(SiteID) %>%
  mutate(
    tmax_lag0 = tmax,
    tmax_lag1 = lag(tmax, 1),
    tmax_lag2 = lag(tmax, 2),
    tmax_lag3 = lag(tmax, 3)
  ) %>%
  ungroup()

corrs<-monthly_ndvi_tmax %>%
  group_by(SiteID) %>%
  summarise(
    lag0 = cor(meanNDVI, tmax_lag0, use = "complete.obs"),
    p_lag0 = cor.test(meanNDVI, tmax_lag0)$p.value,
    lag1 = cor(meanNDVI, tmax_lag1, use = "complete.obs"),
    p_lag1 = cor.test(meanNDVI, tmax_lag1)$p.value,
    lag2 = cor(meanNDVI, tmax_lag2, use = "complete.obs"),
    p_lag2 = cor.test(meanNDVI, tmax_lag2)$p.value,
    lag3 = cor(meanNDVI, tmax_lag3, use = "complete.obs"),
    p_lag3 = cor.test(meanNDVI, tmax_lag3)$p.value
  )
corrs #significance decreases with longer lag times, not significant anymore at lag 3

monthly_ndvi_tmax_long <- monthly_ndvi_tmax %>%
  pivot_longer(
    cols = starts_with("tmax_lag"),
    names_to = "lag",
    values_to = "temperature"
  )

ggplot(monthly_ndvi_tmax_long,
       aes(temperature, meanNDVI)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  facet_grid(SiteID ~ lag) + #split into different facets for both SiteID and lag
  theme_bw()

ggplot(monthly_ndvi_tmax_long,
       aes(temperature, meanNDVI, colour = lag)) +
  geom_point(alpha=0.2) + #alpha gives transparancy of points, between 1 (fully visible) and 0 (fully transparant)
  geom_smooth(method = "lm", se = FALSE) +
  facet_wrap(~SiteID) +
  theme_bw()

ggplot(monthly_ndvi_tmax_long,
       aes(temperature, meanNDVI, colour = lag)) +
  geom_point(alpha=0.2) +
  geom_smooth(method = "lm", se = FALSE) +
  facet_wrap(~lag) +
  theme_bw()

#consider a quadratic relationship
#first remove missing values
monthly_ndvi_tmax_nona<-monthly_ndvi_tmax[complete.cases(monthly_ndvi_tmax[,c(10,11)]),]
lmemodel_lin <- nlme::lme(meanNDVI ~ tmax_lag0,random = ~1|SiteID , data = monthly_ndvi_tmax_nona)
lmemodel_quad <- nlme::lme(meanNDVI ~ tmax_lag0 + I(tmax_lag0^2),random = ~1|SiteID , data = monthly_ndvi_tmax_nona)
summary(lmemodel_lin)
summary(lmemodel_quad)
r.squaredGLMM(lmemodel_lin)
r.squaredGLMM(lmemodel_quad)
ggplot(monthly_ndvi_tmax, aes(tmax, meanNDVI)) +
  geom_point() +
  stat_smooth(method = "lm", formula = y ~ x, size = 1,col='red') +
  stat_smooth(method = "lm", formula = y ~ x + I(x^2), size = 1,col='blue') +
  xlab('Maximum temperature') +
  ylab('NDVI') +
  annotate("text", x=7, y=-0.2, label= "R²m = 0.29, R²c = 0.40",col='red') + 
  annotate("text", x=7, y=-0.3, label= "R²m = 0.30, R²c = 0.40",col='blue') + 
  theme_bw()

#look at relationship between NDVI and temperature anomalies
ggplot(monthly_ndvi_tmax, aes(tmax_an, meanNDVI)) +
  geom_point() +
  geom_smooth(method = "lm", se = TRUE) +
  theme_bw()
ggplot(monthly_ndvi_tmax, aes(tmax_an, meanNDVI)) +
  geom_point() +
  geom_smooth(method = "lm", se = TRUE) +
  facet_wrap(~SiteID) +
  theme_bw()
monthly_ndvi_tmax_an <- monthly_ndvi_tmax %>%
  arrange(SiteID, date) %>%
  group_by(SiteID) %>%
  mutate(
    tmax_an_lag0 = tmax_an,
    tmax_an_lag1 = lag(tmax_an, 1),
    tmax_an_lag2 = lag(tmax_an, 2),
    tmax_an_lag3 = lag(tmax_an, 3)
  ) %>%
  ungroup()
corrs_an<-monthly_ndvi_tmax_an %>%
  group_by(SiteID) %>%
  summarise(
    lag0 = cor(meanNDVI, tmax_an_lag0, use = "complete.obs"),
    p_lag0 = cor.test(meanNDVI, tmax_an_lag0)$p.value,
    lag1 = cor(meanNDVI, tmax_an_lag1, use = "complete.obs"),
    p_lag1 = cor.test(meanNDVI, tmax_an_lag1)$p.value,
    lag2 = cor(meanNDVI, tmax_an_lag2, use = "complete.obs"),
    p_lag2 = cor.test(meanNDVI, tmax_an_lag2)$p.value,
    lag3 = cor(meanNDVI, tmax_an_lag3, use = "complete.obs"),
    p_lag3 = cor.test(meanNDVI, tmax_an_lag3)$p.value
  )
corrs_an #only significant at lag 1 for site A



